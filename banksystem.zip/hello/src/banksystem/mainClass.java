package banksystem;
import java.util.ArrayList;
import java.util.List;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class mainClass {
    public static void main(String[] args) {
        int numAccounts = 10;
        double initialBalance = 1000;
        List<Account> accounts = new ArrayList<>();
        for (int i = 0; i < numAccounts; i++) {
            accounts.add(new Account(i, initialBalance));
        }

        Bank bank = new Bank(accounts);

        ExecutorService executor = Executors.newFixedThreadPool(5);

        for (int i = 0; i < 100; i++) {
            int fromAccountId = (int) (Math.random() * numAccounts);
            int toAccountId = (int) (Math.random() * numAccounts);
            double amount = Math.random() * 100;

            TransferTask task = new TransferTask(bank, fromAccountId, toAccountId, amount);
            executor.submit(task);
        }

        executor.shutdown();
        while (!executor.isTerminated()) {
            // Wait for all tasks to finish
        }

        System.out.println("Final account balances:");
        for (int i = 0; i < numAccounts; i++) {
            System.out.println("Account " + i + ": " + bank.getAccount(i).getBalance());
        }
    }
}