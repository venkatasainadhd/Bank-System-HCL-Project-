package banksystem;
public class Account {
    private final int id;
    private double balance;

    public Account(int id, double initialBalance) {
        this.id = id;
        this.balance = initialBalance;
    }

    public synchronized void deposit(double amount) {
        balance += amount;
    }

    public synchronized void withdraw(double amount) {
        balance -= amount;
    }

    public synchronized double getBalance() {
        return balance;
    }

    public int getId() {
        return id;
    }

    public synchronized void transfer(Account to, double amount) {
        if (this.balance >= amount) {
            this.withdraw(amount);
            to.deposit(amount);
            System.out.println("Transferred " + amount + " from Account " + this.id + " to Account " + to.getId());
        } else {
            System.out.println("Insufficient funds in Account " + this.id);
        }
    }
}

