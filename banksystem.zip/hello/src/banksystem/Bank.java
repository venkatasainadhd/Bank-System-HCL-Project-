package banksystem;

import java.util.List;

public class Bank {
    private final List<Account> accounts;

    public Bank(List<Account> accounts) {
        this.accounts = accounts;
    }

    public Account getAccount(int id) {
        return accounts.get(id);
    }

    public void transfer(int fromAccountId, int toAccountId, double amount) {
        Account fromAccount = getAccount(fromAccountId);
        Account toAccount = getAccount(toAccountId);
        synchronized (fromAccount) {
            synchronized (toAccount) {
                fromAccount.transfer(toAccount, amount);
            }
        }
    }

    public List<Account> getAccounts() {
        return accounts;
    }
}
