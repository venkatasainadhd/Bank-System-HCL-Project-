package banksystem;

public class TransferTask implements Runnable {
    private final Bank bank;
    private final int fromAccountId;
    private final int toAccountId;
    private final double amount;

    public TransferTask(Bank bank, int fromAccountId, int toAccountId, double amount) {
        this.bank = bank;
        this.fromAccountId = fromAccountId;
        this.toAccountId = toAccountId;
        this.amount = amount;
    }

    @Override
    public void run() {
        bank.transfer(fromAccountId, toAccountId, amount);
    }
}

